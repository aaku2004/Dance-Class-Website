# Dance-Website
## Author: Greeshma C Shekar
### Tech and Tools used
- HTML
- CSS
- JavaScript and Jquery embedded in HTML document
- Bootstrap 
- VS Code
##### The website contains a music file which plays automatically (exception chrome)
- Clone the Repository
- Run the index.html page
#### YouTube channel: https://youtu.be/xFgbFJj8RKk
